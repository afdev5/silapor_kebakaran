<?php $__env->startSection('meta'); ?>
<meta name="csrf-token" content="<?php echo e(Session::token()); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="section">
	<h1 class="section-header">
		<div>Maps</div>
	</h1>
	<div class="row">
		<div class="col-12">
			<div id="map" style="width:100%;height: 400px;"></div>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBTKXb5Q14HUjhtIpPprV5iXA84KdO81Yo&callback=initMap" async defer></script>
<script>
	function initMap() {
		var kantor = {
			lat: 1.445948,
			lng: 125.183886
		};
		var lats = "<?php echo e($data['lat']); ?>";
		var long = "<?php echo e($data['long']); ?>";
		var locations = [
			['Kantor Kebakaran', 1.445948, 125.183886, 4, '<h3>Kantor Kebakaran</h3><p>Ini Kantor Kebakaran</p>', '<?php echo e(asset(' assets / img / fire.jpg ')); ?>'],
			['Lokasi Kebakaran', lats, long, 5, '<h3>Lokasi Kebakaran</h3><p>Ini Lokasi Kebakaran</p>', '<?php echo e(asset('assets/img/fire.png')); ?>'],
		];
		var map = new google.maps.Map(
			document.getElementById('map'), {
				zoom: 14,
				center: kantor,
				mapTypeControl: false,
				streetViewControl: false
			});
		var directionsService = new google.maps.DirectionsService();
		var directionsDisplay = new google.maps.DirectionsRenderer();
		directionsDisplay.setOptions({
			suppressMarkers: true
		});
		directionsDisplay.setMap(map);
		var awal = new google.maps.LatLng(1.445948, 125.183886);
		var tujuan = new google.maps.LatLng(lats, long);
		var request = {
			origin: kantor,
			destination: tujuan,
			travelMode: 'DRIVING'
		};
		directionsService.route(request, function (result, status) {
			if (status == 'OK') {
				directionsDisplay.setDirections(result);
				var _route = result.routes[0].legs[0];
				pinA = new google.maps.Marker({
						position: _route.start_location,
						map: map,
						title: 'Kantor Kebakaran',
						infoWindow: {
							content: '<h3>Kantor Kebakaran</h3><p>Ini Kantor Kebakaran</p>'
						}
					}),
					pinB = new google.maps.Marker({
						position: _route.end_location,
						map: map,
						title: 'Lokasi Kebakaran',
						infoWindow: {
							content: '<h3>Lokasi Kebakaran</h3><p>Ini Lokasi Kebakaran</p>'
						}
					});
				console.log(result);
				computeTotalDistance(result);

			}
		});


	}
</script>
<script>
function computeTotalDistance(result) {
		var tokens = "<?php echo e($user['token']); ?>";
		var total = 0;
		var totalDuration = 0;
		var myroute = result.routes[0];
		for (var i = 0; i < myroute.legs.length; i++) {
			total += myroute.legs[i].distance.value;
			totalDuration += myroute.legs[i].duration.value;
		}
		total = total / 1000;
		totalDuration = totalDuration / 60;
		console.log(total + ' km');
		console.log(Math.round(totalDuration) + ' Menit');
		$.post("<?php echo e(route('laapor.store')); ?>", {
			'_token': $('meta[name=csrf-token]').attr('content'),
			'userToken': tokens,
			'jarak': total + ' km',
			'waktu': Math.round(totalDuration) + ' Menit'
		})
		.done(function(data){
			console.log(data);
			alert("Berhasil Mengirim Notifikasi Ke User");
		})
		.fail(function(data){
			console.log(data);
			alert("Gagal Mengirim Notifikasi Ke User");
		})
	}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>