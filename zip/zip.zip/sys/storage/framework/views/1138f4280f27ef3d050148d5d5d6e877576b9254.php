<?php $__env->startSection('content'); ?>
<section class="section">
    <h1 class="section-header">
        <div>Rekapan Laporan</div>
    </h1>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <a href="<?php echo e(route('laporan.create')); ?>" class="pull-right btn btn-success btn-xs">Lihat Detail</a>
                    <div class="float-right">
                        <div class="form-group">
                            <input type="text" name="daterange" class="form-control" value="01/01/2020 - 01/15/2020">

                        </div>
                    </div>
                </div>
                <div class="card-body">

                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    $(function() {
        $('input[name="daterange"]').daterangepicker({
            opens: 'left'
        }, function(start, end, label) {
            console.log("A new date selection was made: " + start.format('YYYY-MM-DD') + ' to ' + end.format('YYYY-MM-DD'));
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>