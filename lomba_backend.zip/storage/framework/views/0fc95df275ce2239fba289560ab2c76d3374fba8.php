<?php $__env->startSection('content'); ?>
	<section class="section">
	  <h1 class="section-header">
	    <div>User</div>
	  </h1>
	  <div class="row">
		  <div class="col-12">
                <div class="card">
                  <div class="card-header">
                  	<!-- <div class="float-right"> -->
                    <a href="<?php echo e(route('user.create')); ?>" class="pull-right btn btn-success btn-xs">Tambah User</a>
                    <!-- </div> -->
                  </div>
                  <div class="card-body">
                    <div class="table-responsive">
                      <table id="table" class="table table-bordered">
                      	<thead>
	                        <tr>
                            <th>No</th>
	                          <th>Nama</th>
                            <th>Nik</th>
                            <th>No Hp</th>
                            <th>Alamat</th>
	                          <th style="width: 150px">#</th>
	                        </tr>
	                    </thead>
	                    <tbody>
                       <?php
                          $no = 1;
                        ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td><?php echo e($no++); ?></td>
                            <td><?php echo e($items->name); ?></td>
                            <td><?php echo e($items->nik); ?></td>
                            <td><?php echo e($items->no_hp); ?></td>
                            <td><?php echo e($items->alamat); ?></td>
                            <td>
                            <form action="<?php echo e(route('user.destroy', $items->id)); ?>" method="post">
                              <?php echo e(csrf_field()); ?>

                              <?php echo e(method_field('DELETE')); ?>

                              <a class="btn btn-sm btn-info" type="submit" href="<?php echo e(route('user.edit',$items->id)); ?>">Edit</a>
                              <button style="color:white;" class="btn btn-sm btn-warning" type="submit" onclick="return confirm('Yakin ingin menghapus data?')">Delete</button>
                            </form>
                            </td>
                          </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                      </tbody>
                      </table>
                    </div>
                  </div>
              </div>   
	  </div>
	</section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
	<script>
            $(document).ready(function() {
                $('#table').DataTable();
            });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>